# Stuff To Do

1) Modify `README.md` and describe your project.
2) Modify `src/wadinfo.txt`, especially the license section. It will become your text file.
3) Add extended credits to `src/credits.txt`.
4) Modify `src/decohack/main.dh` to your liking.
5) Add BMP, GIF, or PNG files to `src/convert/palettes`.
6) Add BMP, GIF, or PNG files to `src/convert/graphics`.
7) Add BMP, GIF, or PNG files to `src/convert/sprites`.
8) Add BMP, GIF, or PNG files to `src/convert/colormaps`.
9) Add BMP, GIF, or PNG files to `src/convert/colormaps-secondary`.
10) Add WAV or AIFF files to `src/convert/sounds`.
11) Add assets to `src/assets` into the appropriate folders.
12) Add BMP, GIF, or PNG files to `src/convert/flats`.
13) Add BMP, GIF, or PNG files to `src/convert/patches`.
14) Add BMP, GIF, or PNG files to `src/convert/texture1`.
15) Add BMP, GIF, or PNG files to `src/convert/texture2`.
16) Add flats to `src/textures/flats`.
17) Add patches to `src/textures/patches`.
18) Add patches to `src/textures/texture1` and `src/textures/texture2`.
19) Edit `src/textures/animflats.wad` for flats that need to be in a specific order.
20) Edit `src/textures/texture1.txt` or `src/textures/texture2.txt`.
21) ...OR delete those files and type `doommake rebuildtextures` to build them from IWAD.
22) Edit `src/textures/defswani.txt` for defining ANIMATED and SWITCHES.
23) Add maps to `src/maps`.
